import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-promise',
  templateUrl: './promise.component.html',
  styleUrls: ['./promise.component.css']
})
export class PromiseComponent implements OnInit {

  primiseVal:any
  spinner:boolean =true
  dellObj={
            brandName:'DELL',
            color:'red'
  }
  hpObj={
          brandName:'HP',
          color:'green'
  }
  notFoundObj={
             brandName:'Nill',
               color:'Nill'
}
  

  constructor() { }

  DellAvailable()
  {
  
      return false
 
  }
  HpAvailable()
  {
    
      return true
   
  }

  ngOnInit(): void {
    let buyLaptop=new Promise((resolve,reject)=>{
    if(this.DellAvailable())
    {
      setTimeout(() => {
        resolve(this.dellObj)

      }, 3000);
    }
    else if(this.HpAvailable())
    {
      setTimeout(() => {
        resolve(this.hpObj)

      }, 3000);
    }
    else{
      setTimeout(() => {
        reject(this.notFoundObj);
 
      }, 3000);
    }
    });
    buyLaptop.then(
      (res)=>{
        console.log('Success =>',res)
        this.primiseVal=res
    }
    ).catch(
      (res)=>{
        console.log('Reject =>',res)
        this.primiseVal=res

      })
      setTimeout(() => {
        this.spinner=false
      }, 3000);
  }



}
