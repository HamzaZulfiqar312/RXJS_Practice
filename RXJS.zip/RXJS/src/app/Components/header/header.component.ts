import { Component, OnInit } from '@angular/core';
import { UtilityDesignService } from 'src/app/Services/utility-design.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
exclusive:boolean =false 
service:boolean=false
name:string='Hamza'

  constructor(private _UtilityDesignService:UtilityDesignService) { }
  ngOnInit(): void {
    this._UtilityDesignService.exclusive.subscribe(res=>{
      this.exclusive=res
    console.log("res is =>"+res)
    })
    
    this._UtilityDesignService.name.subscribe(res=>{
       this.name=res  
    })

    this._UtilityDesignService.service=true
    this.service=this._UtilityDesignService.service
  
  }

}
