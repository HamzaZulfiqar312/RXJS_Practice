import { Component, OnInit } from '@angular/core';
import { from, interval } from 'rxjs';
import { toArray, take } from 'rxjs/operators';

import { UtilityDesignService } from 'src/app/Services/utility-design.service';

@Component({
  selector: 'app-to-array',
  templateUrl: './to-array.component.html',
  styleUrls: ['./to-array.component.css']
})
export class ToArrayComponent implements OnInit {
 fromorignalArr:any
 fromoArrRes:any
 toArrayRes:any
  constructor(private _UtilityDesignService:UtilityDesignService) { }

  ngOnInit(): void {
  }
  toArrayOperator()
  {

    //***** using From Operator *** */
    let fromOprAr=['hamza','kamran','qadir','nadeem','zohib']
    this.fromorignalArr=fromOprAr
    let fromOpr=from(fromOprAr)  
    fromOpr.subscribe(res=>{
        console.log(res)   
        this.fromoArrRes=res
        setTimeout(() => {
          this._UtilityDesignService.print('li','from-li',res)

        }, 3000);

      

      })
    
     this.toArrayRes= fromOpr.pipe(toArray()).subscribe(resu=>{
        console.log(resu)
    
          this._UtilityDesignService.print('p','torarray',resu)

      
      })

      //***** using interval Operator *** */
    let interOprData=interval(2000)
    interOprData.pipe(take(5),toArray()).subscribe(res=>{
      console.log(res)
      this._UtilityDesignService.print('p','inetrval-data',res)
    })
       
  }

}
