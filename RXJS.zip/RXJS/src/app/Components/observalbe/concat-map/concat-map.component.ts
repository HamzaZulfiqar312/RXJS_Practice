import { Component, OnInit } from '@angular/core';
import { from, of } from 'rxjs';
import { concatAll, concatMap, delay, map, mergeAll, mergeMap } from 'rxjs/operators';
import { UtilityDesignService } from 'src/app/Services/utility-design.service';

@Component({
  selector: 'app-concat-map',
  templateUrl: './concat-map.component.html',
  styleUrls: ['./concat-map.component.css']
})
export class ConcatMapComponent implements OnInit {

  constructor(private _UtilityDesignService:UtilityDesignService) { }

  ngOnInit(): void {
  }

  ConcatMapFunction()
  {
     // Example 01
  const source=from(['tech','Comedy','news','sport'])
  source.pipe(
    map((res: any)=>this.getData(res))
  ).subscribe(res=>{
   res.subscribe(res2=>{
     console.log(res2)
   this._UtilityDesignService.print('li','map-li',res2)
   })
  })

// Example 02
source.pipe(
  mergeMap(res=>this.getData(res)),
).subscribe(res=>{
 this._UtilityDesignService.print('li','map-li2',res)
 })

  // Example 03
source.pipe(
 concatMap(res=>this.getData(res)),
).subscribe(res=>{
this._UtilityDesignService.print('li','map-li3',res)
})

  }

  getData(data:any)
  {
   return of(data+' video Uplaoded').pipe(delay(2000))
  }

}
