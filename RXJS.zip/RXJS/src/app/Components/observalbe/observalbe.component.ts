import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-observalbe',
  templateUrl: './observalbe.component.html',
  styleUrls: ['./observalbe.component.css']
})
export class ObservalbeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    let array=['dog','fox','lion']
  }



}
