import { Component, OnInit } from '@angular/core';
import { range } from 'rxjs';

@Component({
  selector: 'app-range',
  templateUrl: './range.component.html',
  styleUrls: ['./range.component.css']
})
export class RangeComponent implements OnInit {

  rangeRes:any
  constructor() { }

  ngOnInit(): void {
  }
  rangeOperator()
  {
    let rangeOpt= range(1,50);
    rangeOpt.subscribe(res=>{
      console.log(res)
      this.rangeRes=res.toString()
    })
    
  }
}
