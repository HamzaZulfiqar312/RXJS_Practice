import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exhaust-map',
  templateUrl: './exhaust-map.component.html',
  styleUrls: ['./exhaust-map.component.css']
})
export class ExhaustMapComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
