import { Component, OnInit } from '@angular/core';
import { concat, interval, merge } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { UtilityDesignService } from 'src/app/Services/utility-design.service';

@Component({
  selector: 'app-merge',
  templateUrl: './merge.component.html',
  styleUrls: ['./merge.component.css']
})
export class MergeComponent implements OnInit {


  constructor(private _UtilityDesignService:UtilityDesignService) { }

  ngOnInit(): void {
  }


  mergeFunction()
{
  let Source1=interval(5000).pipe(map(res=>'Source 1 =>'+res),take(5))
  let Source2=interval(2000).pipe(map(res=>'Source 2=>'+res),take(5))
  let Source3=interval(1000).pipe(map(res=>'Source 3=>'+res),take(5))
  
  merge(Source1,Source2,Source3).pipe(
  ).subscribe(res=>{
    console.log(res)
  this._UtilityDesignService.print('li','from-li',res)
  })
}
}
