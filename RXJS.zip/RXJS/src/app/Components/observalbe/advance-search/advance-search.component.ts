import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { debounceTime, distinctUntilChanged, map, switchMap,   } from 'rxjs/operators';
import { UtilityDesignService } from 'src/app/Services/utility-design.service';

@Component({
  selector: 'app-advance-search',
  templateUrl: './advance-search.component.html',
  styleUrls: ['./advance-search.component.css']
})
export class AdvanceSearchComponent implements AfterViewInit {
apiData:any
dataCount:any =0
formValue:any
  @ViewChild('searchForm') searchForm: NgForm | undefined

@ViewChild('advanceForm') advanceForm :NgForm |undefined



  constructor(private _UtilityDesignService: UtilityDesignService) { }
  ngAfterViewInit(): void {

    const formValue=this.advanceForm?.valueChanges;

formValue?.pipe(
  map(res=>res.SearchValue),
  debounceTime(500),
  distinctUntilChanged(),
  switchMap(data=>this._UtilityDesignService.GetApiData2(data))
).subscribe(res=>{
  console.log(res)      
  this.apiData=res
  this.dataCount=JSON.parse(JSON.stringify(res)).length
})  

  }

} 



// const formValue= this.searchForm?.valueChanges
// formValue?.pipe(
//   map(data=>data.searchTerm),
//   debounceTime(500),
//   distinctUntilChanged(),
//  switchMap(data=>this._UtilityDesignService.GetApiData(data))
// ).subscribe(res=>{
//   console.log(res)
//   this.apiData=res
// //----------------------call the api
// //  this._UtilityDesignService.GetApiData(res).subscribe(res=>{
// //   console.log(res)
// //   this.apiData=res
// //   console.log(this.apiData)
// //   this.dataCount= (JSON.parse(JSON.stringify( this.apiData)).length)    
// // })


// })
