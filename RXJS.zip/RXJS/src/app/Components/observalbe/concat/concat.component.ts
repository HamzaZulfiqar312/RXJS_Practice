import { Component, OnInit } from '@angular/core';
import { concat, interval, merge } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { UtilityDesignService } from 'src/app/Services/utility-design.service';

@Component({
  selector: 'app-concat',
  templateUrl: './concat.component.html',
  styleUrls: ['./concat.component.css']
})
export class ConcatComponent implements OnInit {



  constructor(private _UtilityDesignService:UtilityDesignService) { }

  ngOnInit(): void {
  }


Concat()
{
  let Source1=interval(2000).pipe(map(res=>'Source 1 =>'+res),take(5))
  let Source2=interval(4000).pipe(map(res=>'Source 2=>'+res),take(5))
  let Source3=interval(6000).pipe(map(res=>'Source 3=>'+res),take(5))
  
  concat(Source1,Source2,Source3).pipe(
    // take(5)
  ).subscribe(res=>{
    console.log(res)
  this._UtilityDesignService.print('li','from-li',res)
  })
}


}
