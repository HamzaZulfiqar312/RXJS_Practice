 import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { fromEvent, observable, Observable } from 'rxjs';
import { UtilityDesignService } from 'src/app/Services/utility-design.service';

import { from,of } from 'rxjs';


@Component({
  selector: 'app-fromevent',
  templateUrl: './fromevent.component.html',
  styleUrls: ['./fromevent.component.css']
})
export class FromeventComponent implements OnInit,AfterViewInit {

  @ViewChild('addBtn') addBtn!: ElementRef;  
  @ViewChild('addBtn2') addBtn2!: ElementRef;  

  constructor( private _UtilityDesignService:UtilityDesignService) { }

  ngOnInit(): void {
    this.ObservaleFun()
  }

  ngAfterViewInit(): void {
    let count=0
 
    fromEvent(this.addBtn.nativeElement,'click').subscribe(res=>{
     let vidoE= 'video '+count++;
      this._UtilityDesignService.print('li','elementCont',vidoE)
    }) 

    fromEvent(this.addBtn2.nativeElement,'click').subscribe(res=>{
      alert(res)
    })
 
   }

    AddVideo(){      
      this._UtilityDesignService.print('li','elementCont2','Using JS...')
    }

    ObservaleFun()
    {
      //*********************
      // using Constractot
      //********************/
      let obs=new Observable(observer=>{
        console.log('Observable Start')
        observer.next(1)
        observer.next(2)
        observer.next(3)
        observer.next(4)
        observer.next(5)
        console.log('Observable End')

      })

      obs.subscribe(
        // (response)=>console.log(response),
      //  (error)=>console.log(error),
      //  ()=>console.log('Completed')        
        )
      
    
      }     
}
