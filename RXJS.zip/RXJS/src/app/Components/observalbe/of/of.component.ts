import { Component, OnInit } from '@angular/core';
import { of } from 'rxjs';

@Component({
  selector: 'app-of',
  templateUrl: './of.component.html',
  styleUrls: ['./of.component.css']
})
export class OfComponent implements OnInit {

   OfArray:any
   OfArray2:any
   OrignalData:any
   OrignalData2:any
  constructor() { }

  ngOnInit(): void {
    // this.OfOperator();
  }

  OfOperator()
  {
   //*********************
      //          Of
      //********************/
    
      let arr=[1,2,3,4,5,6]
      this.OrignalData=arr;
      let arrs=['A','B','C','hamza','E',99]
       this.OrignalData2=arrs
     let obsOf=of(arr,arrs)
      obsOf.subscribe(res=>{
        console.log('Response from Of')
        console.log(res)
        this.OfArray=res
     
      })

      let string='Welecom to office'
      let obsofS= of(string).subscribe(res=>{
        console.log('Of string : '+res)
      })
  }





}
