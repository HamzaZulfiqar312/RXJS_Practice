import { Component, OnInit } from '@angular/core';
import { ajax } from 'rxjs/ajax';

@Component({
  selector: 'app-ajax',
  templateUrl: './ajax.component.html',
  styleUrls: ['./ajax.component.css']
})
export class AjaxComponent implements OnInit {

  $ajaxData:any
  $ajaxDataFinal:any
  constructor() { }

  ngOnInit(): void {
  }

  AjaxOperator()
  {
    
    let ajaxOp =ajax('https://coronavirus.m.pipedream.net/')
    ajaxOp.subscribe(res=>{
      this.$ajaxData=res.response;
      this.$ajaxDataFinal= this.$ajaxData.rawData
      console.log(this.$ajaxDataFinal)
           
    })
  }

}
