import { Component, OnInit } from '@angular/core';
import { from, of } from 'rxjs';
import { concatMap, delay, map, mergeMap, switchAll, switchMap } from 'rxjs/operators';
import { UtilityDesignService } from 'src/app/Services/utility-design.service';

@Component({
  selector: 'app-swith-map',
  templateUrl: './swith-map.component.html',
  styleUrls: ['./swith-map.component.css']
})
export class SwithMapComponent implements OnInit {

  constructor(private _UtilityDesignService:UtilityDesignService) { }

  ngOnInit(): void {
  }

  SwitchMapFunction()
  {
  const source=from(['tech','Comedy','news','sport'])
 // Example 01
source.pipe(
  mergeMap(res=>this.getData(res)),
).subscribe(res=>{
 this._UtilityDesignService.print('li','map-li',res)
 })
  

// Example 02
source.pipe(
  concatMap(res=>this.getData(res)),
).subscribe(res=>{
 this._UtilityDesignService.print('li','map-li2',res)
 })

  // Example 03
source.pipe(
 switchMap(res=>this.getData(res)),
).subscribe(res=>{
this._UtilityDesignService.print('li','map-li3',res)
})

  }

  getData(data:any)
  {
   return of(data+' video Uplaoded').pipe(delay(2000))
  }

}
