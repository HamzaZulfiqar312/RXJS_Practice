import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SwithMapComponent } from './swith-map.component';

describe('SwithMapComponent', () => {
  let component: SwithMapComponent;
  let fixture: ComponentFixture<SwithMapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SwithMapComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SwithMapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
