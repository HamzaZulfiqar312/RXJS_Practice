import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { from, interval } from 'rxjs';
import { map, pluck, take, toArray } from 'rxjs/operators';
import { UtilityDesignService } from 'src/app/Services/utility-design.service';

@Component({
  selector: 'app-pluck',
  templateUrl: './pluck.component.html',
  styleUrls: ['./pluck.component.css']
})
export class PluckComponent implements OnInit {
  
  //****  Object  *****/ 
  users=[
    {id:'1',name:'Hamza',is_active:1},
    {id:'2',name:'Aslam',is_active:0},
    {id:'3',name:'Asim',is_active:0},
    {id:'4',name:'Nabeel',is_active:1},
    {id:'5',name:'Kamran',is_active:0},
    {id:'6',name:'Saad',is_active:1},
    {id:'7',name:'Ali',is_active:0},
    {id:'8',name:'Ahmed',is_active:1}
   ]
   @ViewChild('head') !head:ElementRef | undefined


  constructor(private _UtilityDesignService:UtilityDesignService) { }
  ngOnInit(): void {
  }

    //****  Pluck  *****/ 
  PluckOperator()
  {
    let pluckOp= from(this.users)
    pluckOp.pipe(
      pluck('name'),
     
      ).subscribe(res=>{
      console.log(res)
  this._UtilityDesignService.print('li','pluck-li',res)
    

})
// let el=document.createElement('h1')
// el.innerText='Hi this is Headning....'

  
}
}
