import { Component, OnInit } from '@angular/core';
import { from, interval, of, pipe, range, Subscription, zip } from 'rxjs';
import { filter, map, toArray } from 'rxjs/operators';
import { UtilityDesignService } from 'src/app/Services/utility-design.service';

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css']
})
export class MapComponent implements OnInit {
 subs1 :Subscription | undefined
 result:any
  constructor(private _UtilityDesignService:UtilityDesignService) { }

  ngOnInit(): void {
  }
  MapOperator()
  {
    // Example 01
    let mapE1= interval(1000)
    this.subs1= mapE1.pipe(
      map(data=>'Map Ex-01 '+data)
      ).subscribe(res=>{
      console.log(res)
      this._UtilityDesignService.print('li','map-li',res)
    },
    error=>alert('error'),
    ()=>alert('completed')
    )

    setTimeout(() => {
      this.subs1?.unsubscribe()
    }, 5000);

    // Example 02
    let users=[
      {id:'1',name:'Hamza',is_active:1},
      {id:'2',name:'Aslam',is_active:0},
      {id:'3',name:'Asim',is_active:0},
      {id:'4',name:'Nabeel',is_active:1},
      {id:'5',name:'Kamran',is_active:0},
      {id:'6',name:'Saad',is_active:1},
      {id:'7',name:'Ali',is_active:0},
      {id:'8',name:'Ahmed',is_active:1}
     ]

    let mapE2=from(users)
      mapE2.pipe(
                  map(data=>data.name,toArray())
                  ).subscribe(res=>{
        this.result=res
        this._UtilityDesignService.print('li','map-li2',res)
        
      })
           
     
  }

  
}
