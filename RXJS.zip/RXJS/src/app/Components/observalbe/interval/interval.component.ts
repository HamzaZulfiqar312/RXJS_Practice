import { Component, ElementRef, OnInit, ViewChild,AfterViewInit} from '@angular/core';
import { interval } from 'rxjs';

@Component({
  selector: 'app-interval',
  templateUrl: './interval.component.html',
  styleUrls: ['./interval.component.css']
})
export class IntervalComponent implements OnInit {
 OprRes:any
 progressSubscraption:any
 @ViewChild('myProgress')
  myProgress!: ElementRef;

@ViewChild('myBar') myBar!:ElementRef
  constructor() { }

  ngOnInit(): void {

  }
  IntervalOperator()
  {
    let intervalOpr= interval(500)
   this.progressSubscraption=intervalOpr.subscribe(res=>{
      console.log(res)
     this.OprRes=res
     this.myBar.nativeElement.style.width=this.OprRes+'%'

     if(this.OprRes>99)
     {
       this.progressSubscraption.unsubscribe()
     }
    })
  
  }

}
