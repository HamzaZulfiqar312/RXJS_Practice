import { Component, OnInit } from '@angular/core';
import { Observable, Observer } from 'rxjs';
import { UtilityDesignService } from 'src/app/Services/utility-design.service';

@Component({
  selector: 'app-custom-observable',
  templateUrl: './custom-observable.component.html',
  styleUrls: ['./custom-observable.component.css']
})
export class CustomObservableComponent implements OnInit {

   customObsData:any
   techStatusClass:any
   constructor(private _UtilityDesignService:UtilityDesignService) { }

  ngOnInit(): void {
    this.sum(10,20)
  }
  CustomObservable()
  {
    // Example 01
    const arr=[1,2,3,4,5]
    const arr2=['A','b','c','d','e']
    const observer = new Observable((ob)=>{
      
    setTimeout(() => {
      ob.next('Angular')
    }, 1000);
    
    setTimeout(() => {
      ob.next('React JS')

    }, 2000);
    
    setTimeout(() => {
      ob.next('Node JS')

    }, 3000);

    setTimeout(() => {
      ob.next('.Net Core')
      ob.complete()
    }, 4000);
    
    setTimeout(() => {
      ob.next('JavaScript')
    }, 5000);
     
    }).subscribe(res=>{
      console.log(res)
      this.customObsData=res
      this._UtilityDesignService.print('li','from-li2',res)
    },
    error=>{
      this.techStatusClass='error'
    },
    ()=>{this.techStatusClass='completed'}
    )
  }


sum(a:any,b:any)
{
 
  const c=a+b;
console.log('Sum is :'+c )

}


}
