import { Component, OnInit } from '@angular/core';
import { from, of } from 'rxjs';
import { map, mergeAll, mergeMap, retry } from 'rxjs/operators';
import { UtilityDesignService } from 'src/app/Services/utility-design.service';

@Component({
  selector: 'app-merge-map',
  templateUrl: './merge-map.component.html',
  styleUrls: ['./merge-map.component.css']
})
export class MergeMapComponent implements OnInit {

  constructor(private _UtilityDesignService:UtilityDesignService) { }

  ngOnInit(): void {
  }

mergeFunction()
{
  // Example 01
  const source=from(['tech','Comedy','news','sport'])
   source.pipe(
     map(res=>this.getData(res))
   ).subscribe(res=>{
    res.subscribe(res2=>{
      console.log(res2)
    this._UtilityDesignService.print('li','map-li',res2)
    })
   })

 // Example 02
 source.pipe(
   map(res=>this.getData(res)),
   mergeAll()
 ).subscribe(res=>{
  this._UtilityDesignService.print('li','map-li2',res)
  })

   // Example 03
 source.pipe(
  mergeMap(res=>this.getData(res)),
).subscribe(res=>{
 this._UtilityDesignService.print('li','map-li3',res)
 })
 
}




getData(data:any)
{
 return of(data+' video Uplaoded')
}

}
