import { Component, OnInit } from '@angular/core';
import { from, pipe } from 'rxjs';
import { tap } from 'rxjs/operators';

@Component({
  selector: 'app-tap',
  templateUrl: './tap.component.html',
  styleUrls: ['./tap.component.css']
})
export class TapComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  TapOperator(){
  let tapArr=['Apple','Mango','Banana','Orange']
  
  from(tapArr).subscribe(res=>{
   pipe(
    tap()
   )
   console.log(res)

  })

  }
}
