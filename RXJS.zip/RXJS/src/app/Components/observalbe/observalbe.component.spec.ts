import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ObservalbeComponent } from './observalbe.component';

describe('ObservalbeComponent', () => {
  let component: ObservalbeComponent;
  let fixture: ComponentFixture<ObservalbeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ObservalbeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ObservalbeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
