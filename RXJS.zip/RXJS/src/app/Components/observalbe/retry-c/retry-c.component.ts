import { Component, OnInit } from '@angular/core';
import { ajax } from 'rxjs/ajax';
import { retry } from 'rxjs/operators';
@Component({
  selector: 'app-retry-c',
  templateUrl: './retry-c.component.html',
  styleUrls: ['./retry-c.component.css']
})
export class RetryCComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    this.RetryOperator()
  }
  RetryOperator()
  {
   

    let coronaData= ajax('https://coronavirus.m.pipedream.net/')
    coronaData.pipe(retry(5)).subscribe(res=>{
      console.log(res.response.rawData)
    })
  }

}
