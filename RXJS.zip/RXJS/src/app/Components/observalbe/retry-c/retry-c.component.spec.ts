import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RetryCComponent } from './retry-c.component';

describe('RetryCComponent', () => {
  let component: RetryCComponent;
  let fixture: ComponentFixture<RetryCComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RetryCComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RetryCComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
