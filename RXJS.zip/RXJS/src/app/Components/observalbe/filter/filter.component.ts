import { Component, OnInit } from '@angular/core';
import { from } from 'rxjs';
import { filter, toArray } from 'rxjs/operators';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.css']
})
export class FilterComponent implements OnInit {


  users=[
    {id:'1',name:'Hamza',gender:'male',is_active:1},
    {id:'2',name:'Aslam',gender:'male',is_active:0},
    {id:'3',name:'Asim',gender:'male',is_active:0},
    {id:'4',name:'Nabeel',gender:'male',is_active:1},
    {id:'5',name:'Kamran',gender:'male',is_active:0},
    {id:'6',name:'Fatime',gender:'female',is_active:1},
    {id:'7',name:'Almas',gender:'female',is_active:0},
  ]
  data:any
  constructor() { }
 arr :[]|undefined
  ngOnInit(): void {
  }
  FilterOperator()
  {
     
    let filterOpr=from(this.users)
    filterOpr.pipe(
      filter(r=>r.name.length>=6),
      toArray(),
      ).subscribe(res=>{
    this.data=res
    })

    const fruits=from([
      "apple",
      "apple",
      "old-apple",
      "apple",
      "banana",
      "old-banana",
      "banana",
      "old-apple",

    ])

     fruits.pipe(
       filter(data=> data!=='old-apple' && data!=='old-banana')
     ).subscribe(res=>{
       console.log(res)
     })
  }

}
