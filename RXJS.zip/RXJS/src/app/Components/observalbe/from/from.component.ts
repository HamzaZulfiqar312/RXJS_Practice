import { Component, OnInit } from '@angular/core';
import { from } from 'rxjs';
import { UtilityDesignService } from 'src/app/Services/utility-design.service';

@Component({
  selector: 'app-from',
  templateUrl: './from.component.html',
  styleUrls: ['./from.component.css']
})
export class FromComponent implements OnInit {
fromRes:any
fromRes2:any
orignalData:any
  constructor(private _UtilityDesignService:UtilityDesignService) { }

  ngOnInit(): void {
    
     
      
  }
  fromOperator()
  {
 
  //*********************
  //      from
  //********************/
  // Example 01
    let arrF=[50,60,70,80]
    this.orignalData=arrF
    let obsFrom= from(arrF);
    obsFrom.subscribe(res=>{
    this.fromRes=JSON.stringify(res)
    this._UtilityDesignService.print('li','from-li', this.fromRes)
    })
  
  //*********************
  //     Example 02
  //*********************

    let arrF2=['hamza','asim','nabeel','kamran']
    let obsFrom2=from(arrF2).subscribe(res=>{
    console.log(res)
    this.fromRes2=res
    this._UtilityDesignService.print('li','from-li2',this.fromRes2)     
    })

    let string='Welecom to office'
    let obsofS= from(string).subscribe(res=>{
    console.log('Of string : '+res)
    })

  }

}
