import { Component, OnInit } from '@angular/core';
import { UtilityDesignService } from 'src/app/Services/utility-design.service';

@Component({
  selector: 'app-comp1',
  templateUrl: './comp1.component.html',
  styleUrls: ['./comp1.component.css']
})
export class Comp1Component implements OnInit {

  constructor(private _UtilityDesignService:UtilityDesignService) { }
user:any
  ngOnInit(): void {
    this._UtilityDesignService.name.subscribe(res=>{
      this.user=res
    })
  }
  ChangeName(name:any)
  {
    console.log(name.value)
    if(name.value!=null && name.value!='' )
    {
    this._UtilityDesignService.name.next(name.value)
  }
  }
}
