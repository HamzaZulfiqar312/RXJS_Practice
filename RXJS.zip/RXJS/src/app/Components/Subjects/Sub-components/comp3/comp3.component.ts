import { Component, OnInit } from '@angular/core';
import { UtilityDesignService } from 'src/app/Services/utility-design.service';

@Component({
  selector: 'app-comp3',
  templateUrl: './comp3.component.html',
  styleUrls: ['./comp3.component.css']
})
export class Comp3Component implements OnInit {

  user:any
  constructor(private _UtilityDesignService:UtilityDesignService) { }

  ngOnInit(): void {
    this._UtilityDesignService.name.subscribe(res=>{
      this.user=res
    })
  }
  ChangeName(name:any)
  {
    console.log(name.value)
    this._UtilityDesignService.name.next(name.value)
  }
}
