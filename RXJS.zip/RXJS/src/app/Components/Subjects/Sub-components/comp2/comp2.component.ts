import { Component, OnInit } from '@angular/core';
import { UtilityDesignService } from 'src/app/Services/utility-design.service';

@Component({
  selector: 'app-comp2',
  templateUrl: './comp2.component.html',
  styleUrls: ['./comp2.component.css']
})
export class Comp2Component implements OnInit {
user:any
  constructor(private _UtilityDesignService:UtilityDesignService) { }

  ngOnInit(): void {
    this._UtilityDesignService.name.subscribe(res=>{
      this.user=res
    })
  }
  ChangeName(name:any)
  {
    console.log(name.value)
    this._UtilityDesignService.name.next(name.value)
  }
}

