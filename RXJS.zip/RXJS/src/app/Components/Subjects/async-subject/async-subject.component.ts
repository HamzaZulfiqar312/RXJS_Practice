import { Component, OnInit } from '@angular/core';
import { UtilityDesignService } from 'src/app/Services/utility-design.service';

@Component({
  selector: 'app-async-subject',
  templateUrl: './async-subject.component.html',
  styleUrls: ['./async-subject.component.css']
})
export class AsyncSubjectComponent implements OnInit {
AsyncUser:any
  constructor(private _UtilityDesignService:UtilityDesignService) { }

  ngOnInit(): void {
    this._UtilityDesignService.asyncuser.subscribe(res=>{
     this.AsyncUser=res
    })
  }
  AddUser(user:any)
  {
  console.log(user.value)
   this._UtilityDesignService.asyncuser.next(user.value)
  //this._UtilityDesignService.print('li','from-li2','User :' +user.value)
  }
  Oncomplete()
  {
    this._UtilityDesignService.asyncuser.complete()
  }

}
