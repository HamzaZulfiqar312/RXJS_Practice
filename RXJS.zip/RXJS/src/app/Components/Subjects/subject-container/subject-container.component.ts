import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subject-container',
  templateUrl: './subject-container.component.html',
  styleUrls: ['./subject-container.component.css']
})
export class SubjectContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
