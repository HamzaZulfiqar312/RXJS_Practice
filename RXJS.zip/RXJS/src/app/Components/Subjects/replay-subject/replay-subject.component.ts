import { Component, OnInit } from '@angular/core';
import { interval, Subscription } from 'rxjs';
import { UtilityDesignService } from 'src/app/Services/utility-design.service';

@Component({
  selector: 'app-replay-subject',
  templateUrl: './replay-subject.component.html',
  styleUrls: ['./replay-subject.component.css']
})
export class ReplaySubjectComponent implements OnInit {
  

  UserList1 =[] as any
  UserList2=[] as any
  UserList3=[] as any
  subscribe2:boolean=false
  subscribe3:boolean=false
  subscraption2:Subscription |undefined
  subscraption3:Subscription |undefined
  toogle:boolean=false
  toogleSubs:Subscription | undefined 
  constructor(private _UtilityDesignService:UtilityDesignService) { }

  ngOnInit(): void {
    this._UtilityDesignService.user.subscribe(res=>{
      // this.UserList1.push(res)   
     console.log(res)
     console.log( typeof(res))
     this.UserList1.push(res);
    })
  }
  AddUser(user:any)
  {
    this._UtilityDesignService.user.next(user.value)
  }
  ChangeSubscraption2()
  {

    if(this.subscribe2)
    {
     this.subscraption2?.unsubscribe()
     this.subscribe2=!this.subscribe2

    }
   else{
    this.subscribe2=!this.subscribe2
    this.subscraption2= this._UtilityDesignService.user.subscribe(res=>{
       this.UserList2.push(res)
     })  
   }
  }

  ChangeSubscraption3()
  {
    if(this.subscribe3)
    {
      this.subscraption3?.unsubscribe()
      this.subscribe3=!this.subscribe3
    }
    else{
      this.subscribe3=!this.subscribe3
      this.subscraption3= this._UtilityDesignService.user.subscribe(res=>{
         this.UserList3.push(res)
       })
    }
 
  }

  ToogleClick()
  {
    this.toogle=!this.toogle

    if(this.toogle)
    {
      let intervals= interval(1000)
      this.toogleSubs= intervals.subscribe(res=>{
        this._UtilityDesignService.user.next(res.toString())
       })
  
    }
    else{
      this.toogleSubs?.unsubscribe()
    }

  }

}


