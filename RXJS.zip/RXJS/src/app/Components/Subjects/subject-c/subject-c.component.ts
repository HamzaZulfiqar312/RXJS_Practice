import { Component, OnDestroy, OnInit } from '@angular/core';
import { UtilityDesignService } from 'src/app/Services/utility-design.service';

@Component({
  selector: 'app-subject-c',
  templateUrl: './subject-c.component.html',
  styleUrls: ['./subject-c.component.css']
})
export class SubjectCComponent implements OnInit ,OnDestroy {

  constructor(private _UtilityDesignService:UtilityDesignService) { }

  ngOnInit(): void {
    this._UtilityDesignService.exclusive.next(true)
  }

  ngOnDestroy(): void {
    this._UtilityDesignService.exclusive.next(false)
  }
   


}
