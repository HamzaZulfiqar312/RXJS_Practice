import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PromiseComponent } from './Components/promise/promise.component';
import { ObservalbeComponent } from './Components/observalbe/observalbe.component';
import { ListComponent } from './Components/observalbe/list/list.component';
import { FromeventComponent } from './Components/observalbe/fromevent/fromevent.component';
import { OfComponent } from './Components/observalbe/of/of.component';
import { FromComponent } from './Components/observalbe/from/from.component';
import { IntervalComponent } from './Components/observalbe/interval/interval.component';
import { RangeComponent } from './Components/observalbe/range/range.component';
import { ToArrayComponent } from './Components/observalbe/to-array/to-array.component';
import { CustomObservableComponent } from './Components/observalbe/custom-observable/custom-observable.component';
import { MapComponent } from './Components/observalbe/map/map.component';
import { PluckComponent } from './Components/observalbe/pluck/pluck.component';
import { FilterComponent } from './Components/observalbe/filter/filter.component';
import { TapComponent } from './Components/observalbe/tap/tap.component';
import { IntroComponent } from './Components/intro/intro.component';
import { AjaxComponent } from './Components/observalbe/ajax/ajax.component';
import { RetryCComponent } from './Components/observalbe/retry-c/retry-c.component';
import { HeaderComponent } from './Components/header/header.component';
import { SubjectCComponent } from './Components/Subjects/subject-c/subject-c.component';
import { Comp1Component } from './Components/Subjects/Sub-components/comp1/comp1.component';
import { Comp2Component } from './Components/Subjects/Sub-components/comp2/comp2.component';
import { Comp3Component } from './Components/Subjects/Sub-components/comp3/comp3.component';
import { ReplaySubjectComponent } from './Components/Subjects/replay-subject/replay-subject.component';
import { AsyncSubjectComponent } from './Components/Subjects/async-subject/async-subject.component';
import { SubjectContainerComponent } from './Components/Subjects/subject-container/subject-container.component';
import { ConcatComponent } from './Components/observalbe/concat/concat.component';
import { MergeComponent } from './Components/observalbe/merge/merge.component';
import { MergeMapComponent } from './Components/observalbe/merge-map/merge-map.component';
import { ConcatMapComponent } from './Components/observalbe/concat-map/concat-map.component';
import { SwithMapComponent } from './Components/observalbe/swith-map/swith-map.component';
import { AdvanceSearchComponent } from './Components/observalbe/advance-search/advance-search.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ExhaustMapComponent } from './Components/observalbe/exhaust-map/exhaust-map.component';


@NgModule({
  declarations: [
    AppComponent,
    PromiseComponent,
    ObservalbeComponent,
    ListComponent,
    FromeventComponent,
    OfComponent,
    FromComponent,
    IntervalComponent,
    RangeComponent,
    ToArrayComponent,
    CustomObservableComponent,
    MapComponent,
    PluckComponent,
    FilterComponent,
    TapComponent,
    IntroComponent,
    AjaxComponent,
    RetryCComponent,
    HeaderComponent,

    // Subjects
    SubjectCComponent,
    Comp1Component,
    Comp2Component,
    Comp3Component,
    ReplaySubjectComponent,
    AsyncSubjectComponent,
    SubjectContainerComponent,
    ConcatComponent,
    MergeComponent,
    MergeMapComponent,
    ConcatMapComponent,
    SwithMapComponent,
    AdvanceSearchComponent,
    ExhaustMapComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
