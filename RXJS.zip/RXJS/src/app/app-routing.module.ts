import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IntroComponent } from './Components/intro/intro.component';
import { AdvanceSearchComponent } from './Components/observalbe/advance-search/advance-search.component';
import { AjaxComponent } from './Components/observalbe/ajax/ajax.component';
import { ConcatMapComponent } from './Components/observalbe/concat-map/concat-map.component';
import { ConcatComponent } from './Components/observalbe/concat/concat.component';
import { CustomObservableComponent } from './Components/observalbe/custom-observable/custom-observable.component';
import { ExhaustMapComponent } from './Components/observalbe/exhaust-map/exhaust-map.component';
import { FilterComponent } from './Components/observalbe/filter/filter.component';
import { FromComponent } from './Components/observalbe/from/from.component';
import { FromeventComponent } from './Components/observalbe/fromevent/fromevent.component';
import { IntervalComponent } from './Components/observalbe/interval/interval.component';
import { ListComponent } from './Components/observalbe/list/list.component';
import { MapComponent } from './Components/observalbe/map/map.component';
import { MergeMapComponent } from './Components/observalbe/merge-map/merge-map.component';
import { MergeComponent } from './Components/observalbe/merge/merge.component';
import { ObservalbeComponent } from './Components/observalbe/observalbe.component';
import { OfComponent } from './Components/observalbe/of/of.component';
import { PluckComponent } from './Components/observalbe/pluck/pluck.component';
import { RangeComponent } from './Components/observalbe/range/range.component';
import { RetryCComponent } from './Components/observalbe/retry-c/retry-c.component';
import { SwithMapComponent } from './Components/observalbe/swith-map/swith-map.component';
import { TapComponent } from './Components/observalbe/tap/tap.component';
import { ToArrayComponent } from './Components/observalbe/to-array/to-array.component';
import { PromiseComponent } from './Components/promise/promise.component';
import { AsyncSubjectComponent } from './Components/Subjects/async-subject/async-subject.component';
import { ReplaySubjectComponent } from './Components/Subjects/replay-subject/replay-subject.component';
import { Comp1Component } from './Components/Subjects/Sub-components/comp1/comp1.component';
import { Comp2Component } from './Components/Subjects/Sub-components/comp2/comp2.component';
import { Comp3Component } from './Components/Subjects/Sub-components/comp3/comp3.component';
import { SubjectCComponent } from './Components/Subjects/subject-c/subject-c.component';
import { SubjectContainerComponent } from './Components/Subjects/subject-container/subject-container.component';

const routes: Routes = [
{
  path:'',
  component:IntroComponent

},
  {
  path:'promise',
  component:PromiseComponent
},
{
  path:'observable',
  component:ObservalbeComponent,
  children:[
    {
      path:''
      ,
      component:ListComponent
    },
    {
      path:'fromEvent',
      component:FromeventComponent
    },
    {
      path:'of',
      component:OfComponent
    },
    {
      path:'from',
      component:FromComponent
    },
    {
      path:'interval',
      component:IntervalComponent
    },
    {
      path:'range',
      component:RangeComponent
    },
    {
      path:'toArray',
      component:ToArrayComponent
    },
    {
      path:'custom',
      component:CustomObservableComponent
    },
    {
      path:'map',
      component:MapComponent
    },
    {
      path:'pluck',
      component:PluckComponent
    },
    {
      path:'filter',
      component:FilterComponent
    },
    {
      path:'tap',
      component:TapComponent
    },
    {
      path:'ajax',
      component:AjaxComponent
    },
    {
      path:'retryC',
      component:RetryCComponent

    },
    {
      path:'concat',
      component:ConcatComponent
    },
    {
      path:'merge',
      component:MergeComponent
    },
    {
      path:'merge-map',
      component:MergeMapComponent
    },
    {
      path:'concat-map',
      component:ConcatMapComponent
    },
    {
      path:'switch-map',
      component:SwithMapComponent
    },
    {
      path:'advance-search',
      component:AdvanceSearchComponent
    },
    
      {
        path:'exhaust-map',
        component:ExhaustMapComponent
      }
    
  
  ]
},
{
  path:'Subject-container',
  component:SubjectContainerComponent,
  children:[
    {
      path:'subject',
     component:SubjectCComponent
    },
    {
      path:'comp1',
      component:Comp1Component
    
     },
    {
      path:'comp2',
      component:Comp2Component
    
    },
    {
      path:'comp3',
      component:Comp3Component
    
    },
    {
      path:'replaySubject',
      component:ReplaySubjectComponent
    },
    {
      path:'asyncSubject',
      component:AsyncSubjectComponent
    },
    
  ]
},





];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
