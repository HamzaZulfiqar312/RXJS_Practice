import { TestBed } from '@angular/core/testing';

import { UtilityDesignService } from './utility-design.service';

describe('UtilityDesignService', () => {
  let service: UtilityDesignService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UtilityDesignService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
